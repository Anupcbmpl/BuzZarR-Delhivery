﻿using BuzZarRDelivery.Models;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Security.Claims;

namespace BuzZarRDelivery.Controllers
{
    public class AccountController : Controller
    {
        private readonly IConfiguration _configuration;

        public AccountController(IConfiguration configuration)
        {
            _configuration = configuration;
        }


        public IActionResult Login()
        {
            return View();
        }

        public IActionResult ForgetPassword()
        {
            return View();
        }

        //Post method to get details    
        [HttpPost]
        public JsonResult GetLogInDetails(AccountModel obj)
        {
            Response res = new Response();
            try
            {
                string sqlDataSource = _configuration.GetConnectionString("BuzZarRCon");
                int ret = 0;
                using (SqlConnection myCon = new SqlConnection(sqlDataSource))
                {
                    myCon.Open();
                    SqlCommand myCommand = new SqlCommand("GetLogInDetails", myCon);
                    myCommand.CommandType = CommandType.StoredProcedure;
                    myCommand.Parameters.AddWithValue("@UserName", obj.UserName);
                    myCommand.Parameters.AddWithValue("@Password", obj.Password);
                    myCommand.Parameters.AddWithValue("@LastLoginIP", Util.GetClientIPAddress(HttpContext));
                    SqlDataAdapter sda = new SqlDataAdapter(myCommand);
                    DataTable dt = new DataTable();
                    sda.Fill(dt);
                    if (dt.Rows.Count > 0)
                    {
                        HttpContext.Response.Cookies.Append("UserName", obj.UserName);
                        HttpContext.Response.Cookies.Append("Fullname", dt.Rows[0]["Fullname"].ToString());
                        HttpContext.Response.Cookies.Append("MemberId", dt.Rows[0]["MemberId"].ToString());
                        HttpContext.Response.Cookies.Append("MType", dt.Rows[0]["ret"].ToString());

                        var claims = new List<Claim>() {
                            new Claim(ClaimTypes.NameIdentifier, Convert.ToString(dt.Rows[0]["MemberId"])),
                                new Claim(ClaimTypes.Name, obj.UserName),
                                new Claim(ClaimTypes.Role, dt.Rows[0]["ret"].ToString())
                            };
                        var identity = new ClaimsIdentity(claims, CookieAuthenticationDefaults.AuthenticationScheme);
                        //Initialize a new instance of the ClaimsPrincipal with ClaimsIdentity    
                        var principal = new ClaimsPrincipal(identity);
                        HttpContext.SignInAsync(CookieAuthenticationDefaults.AuthenticationScheme, principal, new AuthenticationProperties()
                        {
                            IsPersistent = obj.IsSelected
                        });

                        ret = Convert.ToInt32(dt.Rows[0]["ret"]);
                        if (ret == 1)
                        {
                            res.Status = ret;
                            res.Message = "/DP/Dashboard";
                        }
                        else if (ret == 2)
                        {
                            res.Status = ret;
                            res.Message = "/MF/Dashboard";
                        }
                        else if (ret == 3)
                        {
                            res.Status = ret;
                            res.Message = "/DF/Dashboard";
                        }
                        else if (ret == 4)
                        {
                            res.Status = ret;
                            res.Message = "/OBP/Dashboard";
                        }
                        else if (ret == 5)
                        {
                            res.Status = ret;
                            res.Message = "/DE/Dashboard";
                        }
                        else
                        {
                            res.Status = ret;
                            res.Message = "Your credential is wrong.Please try with right credential.";
                        }
                    }

                    myCon.Close();
                }
            }
            catch (Exception ex)
            {
                res.Status = -2;
                res.Message = ex.Message;
            }
            return new JsonResult(res);
        }


        [HttpGet]
        public IActionResult Logout()
        {
            //SignOutAsync is Extension method for SignOut    
            HttpContext.SignOutAsync(CookieAuthenticationDefaults.AuthenticationScheme);
            //Redirect to home page    
            return LocalRedirect("/Account/Login");
        }
    }
}
