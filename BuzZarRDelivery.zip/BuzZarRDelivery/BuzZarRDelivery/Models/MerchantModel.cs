﻿using System;

namespace BuzZarRDelivery.Models
{
    public class MerchantModel
    {
        public string Process { get; set; }
        public Int64? M_Id { get; set; }
        public string M_Name { get; set; }
        public string M_MobileNo { get; set; }
        public string M_Email { get; set; }
        public string M_Line1 { get; set; }
        public string M_Line2 { get; set; }
        public string M_Line3 { get; set; }
        public string M_Line4 { get; set; }
        public string M_City { get; set; }
        public string M_State { get; set; }
        public Int64? M_Pin { get; set; }
        public decimal? M_Latitude { get; set; }
        public decimal? M_Longitude { get; set; }
        public int? AccountStatus { get; set; }
        public string StatusTxt { get; set; }
        public DateTime RegDate { get; set; }
        public int PageIndex { get; set; }
        public int PageSize { get; set; } = 20;
        public int Records { get; set; }
    }
}
