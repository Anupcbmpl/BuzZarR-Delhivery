﻿using Microsoft.AspNetCore.Mvc.Rendering;
using System;
using System.Collections.Generic;

namespace BuzZarRDelivery.Models
{

    public class From
    {
        public string M_Name { get; set; }
        public string M_MobileNo { get; set; }
        public string M_Line1 { get; set; }
        public string M_Line2 { get; set; }
        public string M_Line3 { get; set; }
        public string M_Line4 { get; set; }
        public string M_City { get; set; }
        public string M_State { get; set; }
        public Int64? M_Pin { get; set; }
        public decimal? M_Latitude { get; set; }
        public decimal? M_Longitude { get; set; }
        public string M_Tag { get; set; }
    }

    public class To
    {
        public string C_Name { get; set; }
        public string C_MobileNo { get; set; }
        public string C_Line1 { get; set; }
        public string C_Line2 { get; set; }
        public string C_Line3 { get; set; }
        public string C_Line4 { get; set; }
        public string C_City { get; set; }
        public string C_State { get; set; }
        public Int64? C_Pin { get; set; }
        public decimal? C_Latitude { get; set; }
        public decimal? C_Longitude { get; set; }
        public string C_Tag { get; set; }
    }

    public class Items
    {
        public string ProductName { get; set; }
        public string UoM { get; set; }
        public Int64? Quantity { get; set; }
    }

    public class OrderInfo
    {
        public From From { get; set; }
        public To To { get; set; }
        public Int64? OrderId { get; set; }
        public List<Items> Items { get; set; }
        public decimal? Amount { get; set; }
        public decimal? ShippingCharges { get; set; }
        public decimal? Total { get; set; }
        public DateTime OrderDate { get; set; }
    }

    public class OrderModel
    {

        public OrderInfo OrderInfo { get; set; }
        public Items[] Items { get; set; }
        public int? ItemCount { get; set; }
        public decimal? ItemWeight { get; set; }
        public string StatusTxt { get; set; }
        public Int64? OBPID { get; set; }
        public Int64? AssignID { get; set; }
        public int? OrderStatus { get; set; }
        public int PageIndex { get; set; }
        public int PageSize { get; set; } = 20;
        public int Records { get; set; }
        public string Merchant { get; set; }
        public string PickupFrom { get; set; }
        public string Customer { get; set; }
        public string DeliverTo { get; set; }
        public string AssignTo { get; set; }
        public string AssignFrom { get; set; }
        public string Process { get; set; }
        public Int64? HappyCode { get; set; }
        public DateTime Postpone { get; set; }
        public string RejectedMsg { get; set; }
        public string Reason { get; set; }
        public string Message { get; set; }
        public string PostponedDate { get; set; }
        public string MMapLacation { get; set; }
        public string CMapLacation { get; set; }

    }


    public class OrderDashboardModel
    {
        public Int64? MemberId { get; set; }
        public int? TotalOrder { get; set; }
        public int? PendingOrder { get; set; }
        public int? RejectOrder { get; set; }
        public int? CompleteOrder { get; set; }
        public int? AssignedOrder { get; set; }
        public int? PostponedOrder { get; set; }
        public int? TodayTotalOrder { get; set; }
        public int? TodayPendingOrder { get; set; }
        public int? TodayRejectOrder { get; set; }
        public int? TodayCompleteOrder { get; set; }
        public int? TodayAssignedOrder { get; set; }
        public int? TodayPostponedOrder { get; set; }
        public int? TotalMF { get; set; }
        public int? TotalDF { get; set; }
        public int? TotalOBP { get; set; }
        public int? TotalDE { get; set; }

    }
}
