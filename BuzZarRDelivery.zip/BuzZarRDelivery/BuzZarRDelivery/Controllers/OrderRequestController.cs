﻿using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using Microsoft.Extensions.Configuration;
using BuzZarRDelivery.Models;
using System;
using Newtonsoft.Json;

namespace BuzZarRDelivery.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class OrderRequestController : ControllerBase
    {
        private readonly IConfiguration _configuration;
        public OrderRequestController(IConfiguration configuration)
        {
            _configuration = configuration;
        }

        [HttpPost]
        public JsonResult Post(OrderInfo obj)
        {
            int ret = 0;
            OrderResponse res = new OrderResponse();
            try
            {
                string sqlDataSource = _configuration.GetConnectionString("BuzZarRCon");
                using (SqlConnection myCon = new SqlConnection(sqlDataSource))
                {
                    myCon.Open();
                    SqlCommand myCommand = new SqlCommand("Proc_InsertOrderDetails", myCon);
                    myCommand.CommandType = CommandType.StoredProcedure;
                    var json = JsonConvert.SerializeObject(obj);
                    myCommand.Parameters.Add(new SqlParameter("@json", json));
                    //myCommand.Parameters.AddWithValue("@Action", obj.Process);
                    //myCommand.Parameters.AddWithValue("@OrderId", obj.OrderId);
                    //myCommand.Parameters.AddWithValue("@Items", obj.Items);
                    //myCommand.Parameters.AddWithValue("@Amount", obj.Amount);
                    //myCommand.Parameters.AddWithValue("@ShippingCharges", obj.ShippingCharges);
                    //myCommand.Parameters.AddWithValue("@Total", obj.Total);
                    //myCommand.Parameters.AddWithValue("@OrderDate", obj.OrderDate);
                    //myCommand.Parameters.AddWithValue("@M_Name", obj.M_Name);
                    //myCommand.Parameters.AddWithValue("@M_MobileNo", obj.M_MobileNo);
                    //myCommand.Parameters.AddWithValue("@M_Line1", obj.M_Line1);
                    //myCommand.Parameters.AddWithValue("@M_Line2", obj.M_Line2);
                    //myCommand.Parameters.AddWithValue("@M_Line3", obj.M_Line3);
                    //myCommand.Parameters.AddWithValue("@M_Line4", obj.M_Line4);
                    //myCommand.Parameters.AddWithValue("@M_City", obj.M_City);
                    //myCommand.Parameters.AddWithValue("@M_State", obj.M_State);
                    //myCommand.Parameters.AddWithValue("@M_Pin", obj.M_Pin);
                    //myCommand.Parameters.AddWithValue("@M_Latitude", obj.M_Latitude);
                    //myCommand.Parameters.AddWithValue("@M_Longitude", obj.M_Longitude);
                    //myCommand.Parameters.AddWithValue("@M_Tag", obj.M_Tag);
                    //myCommand.Parameters.AddWithValue("@C_Name", obj.C_Name);
                    //myCommand.Parameters.AddWithValue("@C_MobileNo", obj.C_MobileNo);
                    //myCommand.Parameters.AddWithValue("@C_Line1", obj.C_Line1);
                    //myCommand.Parameters.AddWithValue("@C_Line2", obj.C_Line2);
                    //myCommand.Parameters.AddWithValue("@C_Line3", obj.C_Line3);
                    //myCommand.Parameters.AddWithValue("@C_Line4", obj.C_Line4);
                    //myCommand.Parameters.AddWithValue("@C_City", obj.C_City);
                    //myCommand.Parameters.AddWithValue("@C_State", obj.C_State);
                    //myCommand.Parameters.AddWithValue("@C_Pin", obj.C_Pin);
                    //myCommand.Parameters.AddWithValue("@C_Latitude", obj.C_Latitude);
                    //myCommand.Parameters.AddWithValue("@C_Longitude", obj.C_Longitude);
                    //myCommand.Parameters.AddWithValue("@C_Tag", obj.C_Tag);
                    SqlDataAdapter sda = new SqlDataAdapter(myCommand);
                    DataTable dt = new DataTable();
                    sda.Fill(dt);
                    if (dt.Rows.Count > 0)
                    {
                        ret = Convert.ToInt32(dt.Rows[0]["ret"]);
                        if (ret == 1)
                        {
                            res.Status = 1;
                            res.ShippingReference = dt.Rows[0]["ShipRefNo"].ToString();
                            res.Message = "Order Placed Successfully with shippingReference No " + dt.Rows[0]["ShipRefNo"].ToString() + ".";
                            res.createdTS = dt.Rows[0]["OrderDate"].ToString();
                            res.updatedTS = dt.Rows[0]["UpdateDate"].ToString();
                        }
                        else if (ret == -1)
                        {
                            res.Status = ret;
                            res.Message = "No delivery point available for given order.";
                        }
                    }
                    myCon.Close();
                }
            }
            catch (Exception ex)
            {
                res.Status = -2;
                res.Message = ex.Message;
            }
            return new JsonResult(res);
        }

    }
}
