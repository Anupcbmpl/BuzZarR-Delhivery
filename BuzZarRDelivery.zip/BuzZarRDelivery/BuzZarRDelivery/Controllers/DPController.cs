﻿using BuzZarRDelivery.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Diagnostics;
using System.IO;

namespace BuzZarRDelivery.Controllers
{
    public class DPController : Controller
    {
        private readonly IConfiguration _configuration;
        private readonly IWebHostEnvironment webHostEnvironment;

        public DPController(IConfiguration configuration, IWebHostEnvironment hostEnvironment)
        {
            _configuration = configuration;
            webHostEnvironment = hostEnvironment;
        }

        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }

        #region  
        [Authorize]
        public IActionResult Dashboard()
        {
            return View();
        }


        [Authorize]
        public IActionResult My_Profile()
        {
            return View();
        }

        [Authorize]
        public IActionResult MF_Report()
        {
            return View();
        }

        [Authorize]
        [HttpGet]
        public IActionResult MF_Profile(Int64 Id)
        {
            return View();
        }

        [Authorize]
        public IActionResult DF_Report()
        {
            return View();
        }

        [Authorize]
        [HttpGet]
        public IActionResult DF_Profile(Int64 Id)
        {
            return View();
        }

        [Authorize]
        public IActionResult OBP_Report()
        {
            return View();
        }

        [Authorize]
        [HttpGet]
        public IActionResult OBP_Profile(Int64 Id)
        {
            return View();
        }

        [Authorize]
        public IActionResult DE_Report()
        {
            return View();
        }

        [Authorize]
        [HttpGet]
        public IActionResult DE_Profile(Int64 Id)
        {
            return View();
        }

        [Authorize]
        [HttpPost]
        public JsonResult Registration(PropertiesModel obj)
        {
            Response res = new Response();
            try
            {
                string sqlDataSource = _configuration.GetConnectionString("BuzZarRCon");
                int ret = 0;
                using (SqlConnection myCon = new SqlConnection(sqlDataSource))
                {
                    myCon.Open();
                    SqlCommand myCommand = new SqlCommand("Proc_DP_Members", myCon);
                    myCommand.CommandType = CommandType.StoredProcedure;
                    myCommand.Parameters.AddWithValue("@Action", obj.Process);
                    myCommand.Parameters.AddWithValue("@MType", obj.MType);
                    myCommand.Parameters.AddWithValue("@MemberId", obj.MemberId);
                    myCommand.Parameters.AddWithValue("@ParentId", obj.ParentId);
                    myCommand.Parameters.AddWithValue("@UserName", obj.UserName);
                    myCommand.Parameters.AddWithValue("@Password", obj.Password);
                    myCommand.Parameters.AddWithValue("@FirstName", obj.FirstName);
                    myCommand.Parameters.AddWithValue("@LastName", obj.LastName);
                    myCommand.Parameters.AddWithValue("@EmailAddress", obj.EmailAddress);
                    myCommand.Parameters.AddWithValue("@ContactNo", obj.ContactNo);
                    myCommand.Parameters.AddWithValue("@Address", obj.Address);
                    myCommand.Parameters.AddWithValue("@State", obj.State);
                    myCommand.Parameters.AddWithValue("@City", obj.City);
                    myCommand.Parameters.AddWithValue("@ZipCode", obj.ZipCode);
                    myCommand.Parameters.AddWithValue("@Latitude", obj.Latitude);
                    myCommand.Parameters.AddWithValue("@Longitude", obj.Longitude);
                    myCommand.Parameters.AddWithValue("@CreateDate", Util.CurrentDate);
                    myCommand.Parameters.AddWithValue("@EntryBy", HttpContext.Request.Cookies["MemberId"]);
                    using (SqlDataReader dr = myCommand.ExecuteReader())
                    {
                        if (dr.Read())
                        {
                            ret = dr.GetInt32(dr.GetOrdinal("ret"));
                            if (ret == 1)
                            {
                                res.Status = ret;
                                res.Message = "Member Registration Completed Successfully.";
                            }
                            else if (ret == -1)
                            {
                                res.Status = ret;
                                res.Message = "Member Details already exist.";
                            }
                        }
                    }
                    myCon.Close();
                }
            }
            catch (Exception ex)
            {
                res.Status = -2;
                res.Message = ex.Message;
            }
            return new JsonResult(res);
        }

        [Authorize]
        [HttpPost]
        public JsonResult GetData(PropertiesModel obj)
        {
            List<PropertiesModel> MFList = new List<PropertiesModel>();
            string sqlDataSource = _configuration.GetConnectionString("BuzZarRCon");
            using (SqlConnection myCon = new SqlConnection(sqlDataSource))
            {
                myCon.Open();
                SqlCommand cmd = new SqlCommand("Proc_DP_Members", myCon);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@Action", obj.Process);
                cmd.Parameters.AddWithValue("@MemberId", obj.MemberId);
                cmd.Parameters.AddWithValue("@ParentId", obj.ParentId);
                cmd.Parameters.AddWithValue("@MType", obj.MType);
                cmd.Parameters.AddWithValue("@FirstName", obj.FirstName);
                cmd.Parameters.AddWithValue("@LastName", obj.LastName);
                cmd.Parameters.AddWithValue("@EmailAddress", obj.EmailAddress);
                cmd.Parameters.AddWithValue("@ContactNo", obj.ContactNo);
                cmd.Parameters.AddWithValue("@UserName", obj.UserName);
                cmd.Parameters.AddWithValue("@AccountStatus", obj.AccountStatus);
                cmd.Parameters.AddWithValue("@PageIndex", obj.PageIndex);
                cmd.Parameters.AddWithValue("@PageSize", obj.PageSize);
                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.HasRows)
                {
                    while (dr.Read())
                    {
                        PropertiesModel d = new PropertiesModel();
                        d.MemberId = dr.GetInt64(dr.GetOrdinal("MemberId"));
                        d.ParentId = dr.GetInt64(dr.GetOrdinal("ParentId"));
                        d.UserName = dr.GetString(dr.GetOrdinal("UserName"));
                        d.ParentName = dr.GetString(dr.GetOrdinal("ParentName"));
                        d.Password = dr.GetString(dr.GetOrdinal("Password"));
                        d.FirstName = dr.GetString(dr.GetOrdinal("FirstName"));
                        d.LastName = dr.GetString(dr.GetOrdinal("LastName"));
                        d.EmailAddress = dr.GetString(dr.GetOrdinal("EmailAddress"));
                        d.ContactNo = dr.GetString(dr.GetOrdinal("ContactNo"));
                        d.Address = dr.GetString(dr.GetOrdinal("Address"));
                        d.State = dr.GetString(dr.GetOrdinal("State"));
                        d.City = dr.GetString(dr.GetOrdinal("City"));
                        d.ZipCode = dr.GetInt64(dr.GetOrdinal("ZipCode"));
                        d.CreateDate = dr.GetDateTime(dr.GetOrdinal("CreateDate"));
                        d.RegDate = d.CreateDate.ToString("dd-MMM-yy");
                        d.UpdateDate = dr.GetDateTime(dr.GetOrdinal("UpdateDate"));
                        d.State = dr.GetString(dr.GetOrdinal("State"));
                        d.ProfilePhoto = dr.GetString(dr.GetOrdinal("ProfilePhoto"));
                        d.AccountStatus = dr.GetInt32(dr.GetOrdinal("AccountStatus"));
                        d.MType = dr.GetInt32(dr.GetOrdinal("MType"));
                        d.Latitude = dr.GetDecimal(dr.GetOrdinal("Latitude"));
                        d.Longitude = dr.GetDecimal(dr.GetOrdinal("Longitude"));
                        d.Actions = "<div class='btn-group btn-group-xs' role='group'>";
                        if (d.AccountStatus == 1)
                        {
                            d.StatusTxt = "<span class='badge badge-success'>Active</span>";
                            d.Actions += "<a href='javascript:void(0)' class='btn btn-link btn-icon bigger-130 text-danger' title ='Blocked' onclick=\"MemberAction(" + d.MemberId + ",-1)\"><i class='material-icons'>block</i></a>";
                        }
                        else if (d.AccountStatus == -1)
                        {
                            d.StatusTxt = "<span class='badge badge-danger'>Blocked</span>";
                            d.Actions += "<a href='javascript:void(0)' class='btn btn-link btn-icon bigger-130 text-success' title ='Active' onclick=\"MemberAction(" + d.MemberId + ", 1)\"><i class='material-icons'>check</i></a>";
                        }
                        else
                        {
                            d.StatusTxt = "<span class='badge badge-info'>Incomplete</span>";
                            d.Actions += "<a href='javascript:void(0)' class='btn btn-link btn-icon bigger-130 text-success' title ='Active' onclick=\"MemberAction(" + d.MemberId + ",1)\"><i class='material-icons'>check</i></a>";
                            d.Actions += "<a href='javascript:void(0)' class='btn btn-link btn-icon bigger-130 text-danger' title ='Blocked' onclick=\"MemberAction(" + d.MemberId + ",-1)\"><i class='material-icons'>block</i></a>";
                            d.Actions += "<a href='javascript:void(0)' class='btn btn-link btn-icon bigger-130 text-danger' title ='Delete' onclick=\"MemberAction(" + d.MemberId + ",-2)\"><i class='material-icons'>delete_outline</i></a>";
                        }
                        if (d.MType == 2)
                        {
                            d.Actions += "<a href='/DP/MF_Profile/Id=" + d.MemberId + "' class='btn btn-link btn-icon bigger-130 text-primary' title ='View Profile'><i class='material-icons'>visibility</i></a>";
                            d.Actions += "<a href='javascript:void(0)' class='btn btn-link btn-icon bigger-130 text-success' title ='Edit Profile' onclick=\"loadupdate(" + d.MemberId + ",'" + d.FirstName + "','" + d.LastName + "','" + d.EmailAddress + "','" + d.ContactNo + "','" + d.Address + "','" + d.State + "','" + d.City + "','" + d.ZipCode + "','" + d.Latitude + "','" + d.Longitude + "')\"><i class='material-icons'>edit</i></a>";
                        }
                        else if (d.MType == 3)
                        {
                            d.Actions += "<a href='/DP/DF_Profile/Id=" + d.MemberId + "' class='btn btn-link btn-icon bigger-130 text-primary' title ='View Profile'><i class='material-icons'>visibility</i></a>";
                            d.Actions += "<a href='javascript:void(0)' class='btn btn-link btn-icon bigger-130 text-success' title ='Edit Profile' onclick=\"loadupdate(" + d.MemberId + ",'" + d.FirstName + "','" + d.LastName + "','" + d.EmailAddress + "','" + d.ContactNo + "','" + d.Address + "','" + d.State + "','" + d.City + "','" + d.ZipCode + "','" + d.Latitude + "','" + d.Longitude + "','" + d.ParentName + "','" + d.ParentId + "')\"><i class='material-icons'>edit</i></a>";
                        }
                        else if (d.MType == 4)
                        {
                            d.Actions += "<a href='/DP/OBP_Profile/Id=" + d.MemberId + "' class='btn btn-link btn-icon bigger-130 text-primary' title ='View Profile'><i class='material-icons'>visibility</i></a>";
                            d.Actions += "<a href='javascript:void(0)' class='btn btn-link btn-icon bigger-130 text-success' title ='Edit Profile' onclick=\"loadupdate(" + d.MemberId + ",'" + d.FirstName + "','" + d.LastName + "','" + d.EmailAddress + "','" + d.ContactNo + "','" + d.Address + "','" + d.State + "','" + d.City + "','" + d.ZipCode + "','" + d.Latitude + "','" + d.Longitude + "','" + d.ParentName + "','" + d.ParentId + "')\"><i class='material-icons'>edit</i></a>";
                        }
                        else if (d.MType == 5)
                        {
                            d.Actions += "<a href='/DP/DE_Profile/Id=" + d.MemberId + "' class='btn btn-link btn-icon bigger-130 text-primary' title ='View Profile'><i class='material-icons'>visibility</i></a>";
                            d.Actions += "<a href='javascript:void(0)' class='btn btn-link btn-icon bigger-130 text-success' title ='Edit Profile' onclick=\"loadupdate(" + d.MemberId + ",'" + d.FirstName + "','" + d.LastName + "','" + d.EmailAddress + "','" + d.ContactNo + "','" + d.Address + "','" + d.State + "','" + d.City + "','" + d.ZipCode + "','" + d.ParentName + "','" + d.ParentId + "')\"><i class='material-icons'>edit</i></a>";
                        }
                        d.Actions += "</div>";
                        d.Records = dr.GetInt32(dr.GetOrdinal("Records"));
                        MFList.Add(d);
                    }
                }
                else
                {
                    dr.Close();
                }
                myCon.Close();
            }
            return new JsonResult(MFList);
        }

        [Authorize]
        [HttpPost]
        public JsonResult GetDashboardData(OrderDashboardModel obj)
        {
            List<OrderDashboardModel> MFList = new List<OrderDashboardModel>();
            string sqlDataSource = _configuration.GetConnectionString("BuzZarRCon");
            using (SqlConnection myCon = new SqlConnection(sqlDataSource))
            {
                myCon.Open();
                SqlCommand cmd = new SqlCommand("GetDashboard", myCon);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@MemberId", obj.MemberId);
                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.HasRows)
                {
                    while (dr.Read())
                    {
                        OrderDashboardModel d = new OrderDashboardModel();
                        d.TotalOrder = dr.GetInt32(dr.GetOrdinal("TotalOrder"));
                        d.PendingOrder = dr.GetInt32(dr.GetOrdinal("PendingOrder"));
                        d.RejectOrder = dr.GetInt32(dr.GetOrdinal("RejectOrder"));
                        d.CompleteOrder = dr.GetInt32(dr.GetOrdinal("CompleteOrder"));
                        d.AssignedOrder = dr.GetInt32(dr.GetOrdinal("AssignedOrder"));
                        d.PostponedOrder = dr.GetInt32(dr.GetOrdinal("PostponedOrder"));
                        d.TodayTotalOrder = dr.GetInt32(dr.GetOrdinal("TodayTotalOrder"));
                        d.TodayPendingOrder = dr.GetInt32(dr.GetOrdinal("TodayPendingOrder"));
                        d.TodayRejectOrder = dr.GetInt32(dr.GetOrdinal("TodayRejectOrder"));
                        d.TodayCompleteOrder = dr.GetInt32(dr.GetOrdinal("TodayCompleteOrder"));
                        d.TodayAssignedOrder = dr.GetInt32(dr.GetOrdinal("TodayAssignedOrder"));
                        d.TodayPostponedOrder = dr.GetInt32(dr.GetOrdinal("TodayPostponedOrder"));
                        d.TotalMF = dr.GetInt32(dr.GetOrdinal("TotalMF"));
                        d.TotalDF = dr.GetInt32(dr.GetOrdinal("TotalDF"));
                        d.TotalOBP = dr.GetInt32(dr.GetOrdinal("TotalOBP"));
                        d.TotalDE = dr.GetInt32(dr.GetOrdinal("TotalDE"));
                        MFList.Add(d);
                    }
                }
                else
                {
                    dr.Close();
                }
                myCon.Close();
            }
            return new JsonResult(MFList);
        }

        [Authorize]
        [HttpPost]
        public JsonResult ChangeStatus(PropertiesModel obj)
        {
            Response res = new Response();
            try
            {
                string sqlDataSource = _configuration.GetConnectionString("BuzZarRCon");
                int ret = 0;
                using (SqlConnection myCon = new SqlConnection(sqlDataSource))
                {
                    myCon.Open();
                    SqlCommand myCommand = new SqlCommand("Proc_DP_Members", myCon);
                    myCommand.CommandType = CommandType.StoredProcedure;
                    myCommand.Parameters.AddWithValue("@Action", obj.Process);
                    myCommand.Parameters.AddWithValue("@MemberId", obj.MemberId);
                    myCommand.Parameters.AddWithValue("@AccountStatus", obj.AccountStatus);
                    using (SqlDataReader dr = myCommand.ExecuteReader())
                    {
                        if (dr.Read())
                        {
                            ret = dr.GetInt32(dr.GetOrdinal("ret"));
                            if (ret == 1)
                            {
                                res.Status = ret;
                                res.Message = "Member Status Change Successfully.";
                            }
                            else if (ret == -1)
                            {
                                res.Status = ret;
                                res.Message = "Somthing Went Wrong!. Please try after some time.";
                            }
                        }
                    }
                    myCon.Close();
                }
            }
            catch (Exception ex)
            {
                res.Status = -2;
                res.Message = ex.Message;
            }
            return new JsonResult(res);
        }

        [Authorize]
        [HttpPost]
        public JsonResult ChangePassword(PropertiesModel obj)
        {
            Response res = new Response();
            try
            {
                string sqlDataSource = _configuration.GetConnectionString("BuzZarRCon");
                int ret = 0;
                using (SqlConnection myCon = new SqlConnection(sqlDataSource))
                {
                    myCon.Open();
                    SqlCommand myCommand = new SqlCommand("Proc_DP_Members", myCon);
                    myCommand.CommandType = CommandType.StoredProcedure;
                    myCommand.Parameters.AddWithValue("@MemberId", HttpContext.Request.Cookies["MemberId"]);
                    myCommand.Parameters.AddWithValue("@Action", obj.Process);
                    myCommand.Parameters.AddWithValue("@MType", HttpContext.Request.Cookies["MType"]);
                    myCommand.Parameters.AddWithValue("@Password", obj.Password);
                    using (SqlDataReader dr = myCommand.ExecuteReader())
                    {
                        if (dr.Read())
                        {
                            ret = dr.GetInt32(dr.GetOrdinal("ret"));
                            if (ret == 1)
                            {
                                res.Status = ret;
                                res.Message = "Change Password Successfully.";
                            }
                            else if (ret == -1)
                            {
                                res.Status = ret;
                                res.Message = "Something went wrong!. Please try after sometime.";
                            }
                        }
                    }
                    myCon.Close();
                }
            }
            catch (Exception ex)
            {
                res.Status = -2;
                res.Message = ex.Message;
            }
            return new JsonResult(res);
        }

        [Authorize]
        [HttpPost]
        public JsonResult ChangeProfilePhoto(KycDocModel obj)
        {
            Response res = new Response();
            try
            {
                string sqlDataSource = _configuration.GetConnectionString("BuzZarRCon");
                int ret = 0;
                using (SqlConnection myCon = new SqlConnection(sqlDataSource))
                {
                    string uniqueFileName = UploadedFile(obj);
                    myCon.Open();
                    SqlCommand myCommand = new SqlCommand("Proc_DP_Members", myCon);
                    myCommand.CommandType = CommandType.StoredProcedure;
                    myCommand.Parameters.AddWithValue("@Action", obj.Process);
                    myCommand.Parameters.AddWithValue("@MemberId", obj.Id);
                    myCommand.Parameters.AddWithValue("@MType", HttpContext.Request.Cookies["MType"]);
                    myCommand.Parameters.AddWithValue("@ProfilePhoto", uniqueFileName);
                    myCommand.Parameters.AddWithValue("@UpdateDate", Util.CurrentDate);
                    myCommand.Parameters.AddWithValue("@EntryBy", HttpContext.Request.Cookies["MemberId"]);
                    using (SqlDataReader dr = myCommand.ExecuteReader())
                    {
                        if (dr.Read())
                        {
                            ret = dr.GetInt32(dr.GetOrdinal("ret"));
                            if (ret == 1)
                            {
                                res.Status = ret;
                                res.Message = "Profile Photo Change Successfully.";
                            }
                            else if (ret == -1)
                            {
                                res.Status = ret;
                                res.Message = "Somthing went wrong!.Please try after sometime.";
                            }
                        }
                    }
                    myCon.Close();
                }
            }
            catch (Exception ex)
            {
                res.Status = -2;
                res.Message = ex.Message;
            }
            return new JsonResult(res);
        }

        [Authorize]
        [HttpPost]
        public JsonResult KYCDOC(KycDocModel obj)
        {
            Response res = new Response();
            try
            {
                string sqlDataSource = _configuration.GetConnectionString("BuzZarRCon");
                int ret = 0;
                using (SqlConnection myCon = new SqlConnection(sqlDataSource))
                {
                    string uniqueFileName = UploadedFile(obj);
                    myCon.Open();
                    SqlCommand myCommand = new SqlCommand("Proc_MemberKycDoc", myCon);
                    myCommand.CommandType = CommandType.StoredProcedure;
                    myCommand.Parameters.AddWithValue("@Action", obj.Process);
                    myCommand.Parameters.AddWithValue("@UserName", obj.UserName);
                    myCommand.Parameters.AddWithValue("@DocumentType", obj.DocumentType);
                    myCommand.Parameters.AddWithValue("@DocumentNo", obj.DocumentNo);
                    myCommand.Parameters.AddWithValue("@ImageUrl", uniqueFileName);
                    myCommand.Parameters.AddWithValue("@UploadDate", Util.CurrentDate);
                    myCommand.Parameters.AddWithValue("@EntryBy", HttpContext.Request.Cookies["MemberId"]);
                    using (SqlDataReader dr = myCommand.ExecuteReader())
                    {
                        if (dr.Read())
                        {
                            ret = dr.GetInt32(dr.GetOrdinal("ret"));
                            if (ret == 1)
                            {
                                res.Status = ret;
                                res.Message = "KYC Doc Upload Successfully.";
                            }
                            else if (ret == -1)
                            {
                                res.Status = ret;
                                res.Message = "This KYC Doc already exist.";
                            }
                        }
                    }
                    myCon.Close();
                }
            }
            catch (Exception ex)
            {
                res.Status = -2;
                res.Message = ex.Message;
            }
            return new JsonResult(res);
        }

        [Authorize]
        [HttpPost]
        public JsonResult GetKycDoc(KycDocModel obj)
        {
            List<KycDocModel> KYCList = new List<KycDocModel>();
            string sqlDataSource = _configuration.GetConnectionString("BuzZarRCon");
            using (SqlConnection myCon = new SqlConnection(sqlDataSource))
            {
                myCon.Open();
                SqlCommand cmd = new SqlCommand("Proc_MemberKycDoc", myCon);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@Action", obj.Process);
                cmd.Parameters.AddWithValue("@UserName", obj.UserName);
                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.HasRows)
                {
                    while (dr.Read())
                    {
                        KycDocModel d = new KycDocModel();
                        d.Id = dr.GetInt64(dr.GetOrdinal("Id"));
                        d.UserName = dr.GetString(dr.GetOrdinal("UserName"));
                        d.DocumentType = dr.GetString(dr.GetOrdinal("DocumentType"));
                        d.DocumentNo = dr.GetString(dr.GetOrdinal("DocumentNo"));
                        d.ImageUrl = dr.GetString(dr.GetOrdinal("ImageUrl"));
                        d.UploadDate = dr.GetDateTime(dr.GetOrdinal("UploadDate"));
                        d.Date = d.UploadDate.ToString("dd-MMM-yy");
                        d.Status = dr.GetInt32(dr.GetOrdinal("Status"));
                        KYCList.Add(d);
                    }
                }
                else
                {
                    dr.Close();
                }
                myCon.Close();
            }
            return new JsonResult(KYCList);
        }

        [Authorize]
        [HttpPost]
        public JsonResult KycDocAction(KycDocModel obj)
        {
            Response res = new Response();
            try
            {
                string sqlDataSource = _configuration.GetConnectionString("BuzZarRCon");
                int ret = 0;
                using (SqlConnection myCon = new SqlConnection(sqlDataSource))
                {
                    myCon.Open();
                    SqlCommand myCommand = new SqlCommand("Proc_MemberKycDoc", myCon);
                    myCommand.CommandType = CommandType.StoredProcedure;
                    myCommand.Parameters.AddWithValue("@Action", obj.Process);
                    myCommand.Parameters.AddWithValue("@Id", obj.Id);
                    myCommand.Parameters.AddWithValue("@Status", obj.Status);
                    using (SqlDataReader dr = myCommand.ExecuteReader())
                    {
                        if (dr.Read())
                        {
                            ret = dr.GetInt32(dr.GetOrdinal("ret"));
                            if (ret == 1)
                            {
                                res.Status = ret;
                                res.Message = "Kyc Doc Status Change Successfully.";
                            }
                            else if (ret == -1)
                            {
                                res.Status = ret;
                                res.Message = "Somthing Went Wrong!. Please try after some time.";
                            }
                        }
                    }
                    myCon.Close();
                }
            }
            catch (Exception ex)
            {
                res.Status = -2;
                res.Message = ex.Message;
            }
            return new JsonResult(res);
        }

        private string UploadedFile(KycDocModel model)
        {
            string uniqueFileName = null;

            if (model.KycDocImg != null)
            {
                string uploadsFolder = Path.Combine(webHostEnvironment.WebRootPath, "kycDoc");
                uniqueFileName = Guid.NewGuid().ToString() + "_" + model.KycDocImg.FileName;
                string filePath = Path.Combine(uploadsFolder, uniqueFileName);
                using (var fileStream = new FileStream(filePath, FileMode.Create))
                {
                    model.KycDocImg.CopyTo(fileStream);
                }
            }
            return uniqueFileName;
        }

        #endregion

        #region Order_Details
        [Authorize]
        public IActionResult Order_Report()
        {
            return View();
        }

        [Authorize]
        [HttpPost]
        public JsonResult GetOrderList(OrderModel obj)
        {
            List<OrderModel> MFList = new List<OrderModel>();
            string sqlDataSource = _configuration.GetConnectionString("BuzZarRCon");
            using (SqlConnection myCon = new SqlConnection(sqlDataSource))
            {
                myCon.Open();
                SqlCommand cmd = new SqlCommand("GetOrderDetails", myCon);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@OrderId", obj.OrderId);
                cmd.Parameters.AddWithValue("@OBPID", HttpContext.Request.Cookies["MemberId"]);
                cmd.Parameters.AddWithValue("@AssignID", HttpContext.Request.Cookies["MemberId"]);
                cmd.Parameters.AddWithValue("@OrderStatus", obj.OrderStatus);
                cmd.Parameters.AddWithValue("@PageIndex", obj.PageIndex);
                cmd.Parameters.AddWithValue("@PageSize", obj.PageSize);
                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.HasRows)
                {
                    while (dr.Read())
                    {
                        OrderModel d = new OrderModel();
                        d.OrderId = dr.GetInt64(dr.GetOrdinal("OrderId"));
                        d.Items = dr.GetString(dr.GetOrdinal("Items"));
                        d.ItemCount = dr.GetInt32(dr.GetOrdinal("ItemCount"));
                        d.ItemWeight = dr.GetDecimal(dr.GetOrdinal("ItemWeight"));
                        d.Amount = dr.GetDecimal(dr.GetOrdinal("Amount"));
                        d.ShippingCharges = dr.GetDecimal(dr.GetOrdinal("ShippingCharges"));
                        d.Discount = dr.GetDecimal(dr.GetOrdinal("Discount"));
                        d.Total = dr.GetDecimal(dr.GetOrdinal("Total"));
                        d.OrderDate = dr.GetDateTime(dr.GetOrdinal("OrderDate"));
                        d.M_Name = dr.GetString(dr.GetOrdinal("M_Name"));
                        d.M_MobileNo = dr.GetString(dr.GetOrdinal("M_MobileNo"));
                        d.M_Line1 = dr.GetString(dr.GetOrdinal("M_Line1"));
                        d.M_Line2 = dr.GetString(dr.GetOrdinal("M_Line2"));
                        d.M_Line3 = dr.GetString(dr.GetOrdinal("M_Line3"));
                        d.M_Line4 = dr.GetString(dr.GetOrdinal("M_Line4"));
                        d.M_City = dr.GetString(dr.GetOrdinal("M_City"));
                        d.M_State = dr.GetString(dr.GetOrdinal("M_State"));
                        d.M_Pin = dr.GetInt64(dr.GetOrdinal("M_Pin"));
                        d.M_Latitude = dr.GetDecimal(dr.GetOrdinal("M_Latitude"));
                        d.M_Longitude = dr.GetDecimal(dr.GetOrdinal("M_Longitude"));
                        d.M_Tag = dr.GetString(dr.GetOrdinal("C_Name"));
                        d.Merchant = d.M_Name + " " + d.M_MobileNo;
                        d.MMapLacation= "<a href='https://maps.google.com/?q="+ d.M_Latitude + ","+ d.M_Longitude + "' target='_blank'><img src='/img/destination.png' class='img-responsive' alt='Map Location'></a>";
                        d.PickupFrom = d.M_Line1 + " " + d.M_Line2 + " " + d.M_Line3 + " " + d.M_Line4 + " " + d.M_Pin + "&nbsp;&nbsp;&nbsp;" + d.MMapLacation;
                        d.C_Name = dr.GetString(dr.GetOrdinal("C_Name"));
                        d.C_MobileNo = dr.GetString(dr.GetOrdinal("C_MobileNo"));
                        d.C_Line1 = dr.GetString(dr.GetOrdinal("C_Line1"));
                        d.C_Line2 = dr.GetString(dr.GetOrdinal("C_Line2"));
                        d.C_Line3 = dr.GetString(dr.GetOrdinal("C_Line3"));
                        d.C_Line4 = dr.GetString(dr.GetOrdinal("C_Line4"));
                        d.C_City = dr.GetString(dr.GetOrdinal("C_City"));
                        d.C_State = dr.GetString(dr.GetOrdinal("C_State"));
                        d.C_Pin = dr.GetInt64(dr.GetOrdinal("C_Pin"));
                        d.Customer = d.C_Name + " " + d.C_MobileNo;
                        d.C_Latitude = dr.GetDecimal(dr.GetOrdinal("C_Latitude"));
                        d.C_Longitude = dr.GetDecimal(dr.GetOrdinal("C_Longitude"));
                        d.CMapLacation = "<a href='https://maps.google.com/?q=" + d.C_Latitude + "," + d.C_Longitude + "' target='_blank'><img src='/img/destination.png' class='img-responsive' alt='Map Location'></a>";
                        d.DeliverTo = d.C_Line1 + " " + d.C_Line2 + " " + d.C_Line3 + " " + d.C_Line4 + " " + d.C_Pin + "&nbsp;&nbsp;&nbsp;" + d.CMapLacation;
                        d.C_Tag = dr.GetString(dr.GetOrdinal("C_Tag"));
                        d.OBPID = dr.GetInt64(dr.GetOrdinal("OBPID"));
                        d.AssignID = dr.GetInt64(dr.GetOrdinal("AssignID"));
                        d.AssignTo = dr.GetString(dr.GetOrdinal("AssignTo"));
                        d.AssignFrom = dr.GetString(dr.GetOrdinal("AssignFrom"));
                        d.HappyCode = dr.GetInt64(dr.GetOrdinal("HappyCode"));
                        d.Postpone = dr.GetDateTime(dr.GetOrdinal("Postpone"));
                        d.PostponedDate = d.Postpone.ToString("dd-MMM-yy hh:mm tt");
                        d.PickRejMsg = dr.GetString(dr.GetOrdinal("PickRejMsg"));
                        d.CustRejMsg = dr.GetString(dr.GetOrdinal("CustRejMsg"));
                        d.Reason = dr.GetString(dr.GetOrdinal("Reason"));
                        d.OrderStatus = dr.GetInt32(dr.GetOrdinal("OrderStatus"));
                        d.OrderSummary = "<button data-toggle='modal' data-target='#MFRegModal' type='button' class='btn btn-light has-icon'>" + d.OrderId + "</button>";
                        if (d.OrderStatus == 0)
                        {
                            d.StatusTxt = "<span class='badge badge-danger'>Not Assing</span>";

                        }
                        else if (d.OrderStatus == 1)
                        {
                            d.StatusTxt = "<span class='badge badge-success'>Assigned</span>";

                        }
                        else if (d.OrderStatus == 2)
                        {
                            d.StatusTxt = "<span class='badge badge-success'>Picked Done</span>";
                        }

                        else if (d.OrderStatus == 3)
                        {
                            d.StatusTxt = "<span class='badge badge-danger'>Picked Reject</span>";
                        }
                        else if (d.OrderStatus == 4)
                        {
                            d.StatusTxt = "<span class='badge badge-success'>Delivered</span>";
                        }
                        else if (d.OrderStatus == 5)
                        {
                            d.StatusTxt = "<span class='badge badge-danger'>Customer Reject</span>";
                        }
                        else if (d.OrderStatus == 6)
                        {
                            d.StatusTxt = "<span class='badge badge-warning'>Postpone</span>";
                        }
                        else
                        {
                            d.StatusTxt = "<span class='badge badge-danger'>NA</span>";
                        }
                        d.Records = dr.GetInt32(dr.GetOrdinal("Records"));
                        MFList.Add(d);
                    }
                }
                else
                {
                    dr.Close();
                }
                myCon.Close();
            }
            return new JsonResult(MFList);
        }

        [Authorize]
        [HttpPost]
        public JsonResult Dropdown(int AccountStatus, int MType, Int64 ParentId)
        {
            PropertiesModel objp = new PropertiesModel();
            string sqlDataSource = _configuration.GetConnectionString("BuzZarRCon");
            using (SqlConnection myCon = new SqlConnection(sqlDataSource))
            {
                myCon.Open();
                SqlCommand cmd = new SqlCommand("Proc_DP_Members", myCon);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@Action", "Dropdown");
                cmd.Parameters.AddWithValue("@MType", MType);
                cmd.Parameters.AddWithValue("@ParentId", ParentId);
                cmd.Parameters.AddWithValue("@AccountStatus", AccountStatus);
                SqlDataAdapter sda = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                sda.Fill(dt);
                if (dt.Rows.Count > 0)
                {
                    foreach (DataRow ds in dt.Rows)
                    {
                        objp.ItemList.Add(new SelectListItem { Text = Convert.ToString(ds["Name"]), Value = Convert.ToString(ds["MemberId"]) });
                    }
                }
                myCon.Close();
            }
            return Json(new SelectList(objp.ItemList, "Value", "Text"));
        }

        [Authorize]
        [HttpPost]
        public JsonResult GetItemList(Int64 OrderId)
        {
            List<OrderModel> MFList = new List<OrderModel>();
            string sqlDataSource = _configuration.GetConnectionString("BuzZarRCon");
            using (SqlConnection myCon = new SqlConnection(sqlDataSource))
            {
                myCon.Open();
                SqlCommand cmd = new SqlCommand("GetItemList", myCon);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@OrderId", OrderId);
                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.HasRows)
                {
                    while (dr.Read())
                    {
                        OrderModel d = new OrderModel();
                        d.ProductName = dr.GetString(dr.GetOrdinal("ProductName"));
                        d.UoM = dr.GetString(dr.GetOrdinal("UoM"));
                        d.Quantity = dr.GetInt64(dr.GetOrdinal("Quantity"));
                        MFList.Add(d);
                    }
                }
                else
                {
                    dr.Close();
                }
                myCon.Close();
            }
            return new JsonResult(MFList);
        }

        #endregion

    }
}
