﻿namespace BuzZarRDelivery.Models
{
    public class Response
    {
        public int Status { get; set; }
        public string Message { get; set; }
    }

    public class OrderResponse
    {
        public int Status { get; set; }
        public string Message { get; set; }
        public string ShippingReference { get; set; }
        public string createdTS { get; set; }
        public string updatedTS { get; set; }
    }
}
