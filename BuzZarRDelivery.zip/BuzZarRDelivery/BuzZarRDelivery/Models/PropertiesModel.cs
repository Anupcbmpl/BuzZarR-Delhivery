﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc.Rendering;
using System;
using System.Collections.Generic;

namespace BuzZarRDelivery.Models
{
    public class PropertiesModel
    {
        public string Process { get; set; }
        public string Actions { get; set; }
        public Int64? MemberId { get; set; }
        public Int64? ParentId { get; set; }
        public string UserName { get; set; }
        public string Password { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string EmailAddress { get; set; }
        public string ContactNo { get; set; }
        public string Address { get; set; }
        public string State { get; set; }
        public string City { get; set; }
        public Int64? ZipCode { get; set; }
        public int? AccountStatus { get; set; }
        public string StatusTxt { get; set; }
        public DateTime CreateDate { get; set; }
        public DateTime UpdateDate { get; set; }
        public string ProfilePhoto { get; set; }
        public int PageIndex { get; set; }
        public int PageSize { get; set; } = 20;
        public int Records { get; set; }
        public int MType { get; set; }
        public string RegDate { get; internal set; }
        public string ParentName { get; set; }
        public decimal Latitude { get; set; }
        public decimal Longitude { get; set; }

        public PropertiesModel()
        {
            this.ItemList = new List<SelectListItem>();
        }
        public List<SelectListItem> ItemList { get; set; }
    }


    public class KycDocModel
    {
        public string Process { get; set; }
        public Int64? Id { get; set; }
        public string UserName { get; set; }
        public string DocumentType { get; set; }
        public string DocumentNo { get; set; }
        public string ImageUrl { get; set; }
        public IFormFile KycDocImg { get; set; }
        public int? Status { get; set; }
        public string StatusTxt { get; set; }
        public DateTime UploadDate { get; set; }
        public string Date { get; internal set; }
    }
}
