﻿using System;

namespace BuzZarRDelivery.Models
{
    public class AccountModel
    {
        public Int64? Id { get; set; }
        public string UserName { get; set; }
        public string Password { get; set; }
        public string MType { get; set; }
        public bool IsSelected { get; set; }
    }
}
